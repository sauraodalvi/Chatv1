import { useState, useEffect } from 'react';
import { ArrowLeft, Check, Search, Grid, List, Sparkles, Filter, X } from 'lucide-react';
import { characterLibrary } from '../data/characters';

const CharacterSelection = ({ selectedCharacters, setSelectedCharacters, onStartChat, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [characters, setCharacters] = useState([]);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    // Filter characters based on search term and type filter
    let filteredCharacters = [...characterLibrary];

    if (searchTerm) {
      filteredCharacters = filteredCharacters.filter(char =>
        char.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        char.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filter !== 'all') {
      filteredCharacters = filteredCharacters.filter(char =>
        char.type.toLowerCase() === filter.toLowerCase()
      );
    }

    setCharacters(filteredCharacters);
  }, [searchTerm, filter]);

  const toggleCharacterSelection = (character) => {
    if (selectedCharacters.some(char => char.name === character.name)) {
      setSelectedCharacters(selectedCharacters.filter(char => char.name !== character.name));
    } else {
      setSelectedCharacters([...selectedCharacters, character]);
    }
  };

  const selectRandomCharacters = () => {
    // Select 2-4 random characters
    const numToSelect = Math.floor(Math.random() * 3) + 2; // 2-4 characters
    const shuffled = [...characterLibrary].sort(() => 0.5 - Math.random());
    setSelectedCharacters(shuffled.slice(0, numToSelect));
  };

  return (
    <div className="container mx-auto py-4 px-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-3 p-2 rounded-full hover:bg-secondary"
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </button>
          <h1 className="text-2xl font-bold">Select Characters</h1>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1 border rounded-md overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 ${viewMode === 'grid' ? 'bg-primary text-primary-foreground' : 'hover:bg-secondary'}`}
            title="Grid view"
          >
            <Grid className="h-4 w-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 ${viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'hover:bg-secondary'}`}
            title="List view"
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Search and filter controls */}
      <div className="flex items-center gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search characters..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-md border border-input bg-background"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2 rounded-md border ${showFilters ? 'border-primary bg-primary/10' : 'border-input'}`}
          title="Show filters"
        >
          <Filter className="h-4 w-4" />
        </button>

        <button
          onClick={selectRandomCharacters}
          className="p-2 rounded-md border border-input hover:bg-secondary"
          title="Random selection"
        >
          <Sparkles className="h-4 w-4" />
        </button>
      </div>

      {/* Expanded filters */}
      {showFilters && (
        <div className="mb-4 p-3 border rounded-md bg-background/50">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'all' ? 'bg-primary text-primary-foreground' : 'bg-secondary/50 hover:bg-secondary'}`}
            >
              All Types
            </button>
            <button
              onClick={() => setFilter('fantasy')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'fantasy' ? 'bg-purple-500 text-white' : 'bg-purple-500/10 hover:bg-purple-500/20'}`}
            >
              Fantasy
            </button>
            <button
              onClick={() => setFilter('scifi')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'scifi' ? 'bg-blue-500 text-white' : 'bg-blue-500/10 hover:bg-blue-500/20'}`}
            >
              Sci-Fi
            </button>
            <button
              onClick={() => setFilter('historical')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'historical' ? 'bg-amber-500 text-white' : 'bg-amber-500/10 hover:bg-amber-500/20'}`}
            >
              Historical
            </button>
            <button
              onClick={() => setFilter('modern')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'modern' ? 'bg-green-500 text-white' : 'bg-green-500/10 hover:bg-green-500/20'}`}
            >
              Modern
            </button>
            <button
              onClick={() => setFilter('romance')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'romance' ? 'bg-pink-500 text-white' : 'bg-pink-500/10 hover:bg-pink-500/20'}`}
            >
              Romance
            </button>
            <button
              onClick={() => setFilter('adventure')}
              className={`px-3 py-1 text-xs rounded-full ${filter === 'adventure' ? 'bg-orange-500 text-white' : 'bg-orange-500/10 hover:bg-orange-500/20'}`}
            >
              Adventure
            </button>
          </div>
        </div>
      )}

      {/* Selected characters summary */}
      {selectedCharacters.length > 0 && (
        <div className="mb-4 p-3 border border-primary/20 bg-primary/5 rounded-md">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-medium">Selected Characters ({selectedCharacters.length})</h2>
            <button
              onClick={() => setSelectedCharacters([])}
              className="text-xs text-muted-foreground hover:text-foreground"
              title="Clear all"
            >
              Clear all
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {selectedCharacters.map(char => (
              <div
                key={char.name}
                className="bg-primary/10 border border-primary/20 text-primary px-2 py-0.5 rounded-md text-xs flex items-center gap-1"
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    char.type === 'fantasy' ? 'bg-purple-500' :
                    char.type === 'scifi' ? 'bg-blue-500' :
                    char.type === 'historical' ? 'bg-amber-500' :
                    char.type === 'romance' ? 'bg-pink-500' :
                    char.type === 'adventure' ? 'bg-orange-500' :
                    'bg-green-500'
                  }`}
                ></div>
                {char.name}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleCharacterSelection(char);
                  }}
                  className="ml-1 hover:text-red-500"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Character grid/list view */}
      <div className={viewMode === 'grid'
        ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6"
        : "space-y-3 mb-6"
      }>
        {characters.map(character => (
          <div
            key={character.name}
            onClick={() => toggleCharacterSelection(character)}
            className={`rounded-lg border overflow-hidden cursor-pointer transition-all hover:shadow-md ${
              selectedCharacters.some(char => char.name === character.name)
                ? 'border-primary shadow-md'
                : 'border-border hover:border-primary/50'
            } ${viewMode === 'list' ? 'flex' : ''}`}
          >
            {/* Character avatar/header - smaller in list mode */}
            <div className={`relative ${viewMode === 'grid' ? 'h-32' : 'h-24 w-24 flex-shrink-0'} bg-gradient-to-r from-secondary/50 to-primary/30 flex items-center justify-center overflow-hidden`}>
              {character.avatar ? (
                <img
                  src={character.avatar}
                  alt={character.name}
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              ) : (
                <div className={`${viewMode === 'grid' ? 'w-16 h-16' : 'w-12 h-12'} rounded-full flex items-center justify-center ${
                  character.type === 'fantasy' ? 'bg-purple-500' :
                  character.type === 'scifi' ? 'bg-blue-500' :
                  character.type === 'historical' ? 'bg-amber-500' :
                  character.type === 'romance' ? 'bg-pink-500' :
                  character.type === 'adventure' ? 'bg-orange-500' :
                  'bg-green-500'
                } text-white text-xl font-bold`}>
                  {character.name.split(' ').map(n => n[0]).join('')}
                </div>
              )}

              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

              {/* Selection indicator */}
              {selectedCharacters.some(char => char.name === character.name) && (
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground p-1 rounded-full shadow-md z-10">
                  <Check className="h-3 w-3" />
                </div>
              )}

              {/* Character type badge */}
              <div className="absolute top-2 left-2 z-10">
                <span className={`text-xs px-1.5 py-0.5 rounded-full text-white shadow-sm ${
                  character.type === 'fantasy' ? 'bg-purple-500' :
                  character.type === 'scifi' ? 'bg-blue-500' :
                  character.type === 'historical' ? 'bg-amber-500' :
                  character.type === 'romance' ? 'bg-pink-500' :
                  character.type === 'adventure' ? 'bg-orange-500' :
                  'bg-green-500'
                }`}>
                  {character.type}
                </span>
              </div>

              {/* Character name overlay - only in grid mode */}
              {viewMode === 'grid' && (
                <div className="absolute bottom-0 left-0 right-0 p-2 z-10">
                  <h3 className="font-medium text-sm text-white drop-shadow-md">{character.name}</h3>
                </div>
              )}
            </div>

            {/* Character info - more compact */}
            <div className={`p-3 ${viewMode === 'list' ? 'flex-1' : ''}`}>
              {/* Name in list mode */}
              {viewMode === 'list' && (
                <h3 className="font-medium text-sm mb-1">{character.name}</h3>
              )}

              {/* Mood badge - inline in list mode */}
              {viewMode === 'list' && (
                <div className="mb-1.5">
                  <span className="text-xs px-1.5 py-0.5 bg-secondary/50 rounded-full">
                    {character.mood}
                  </span>
                </div>
              )}

              {/* Description - shorter */}
              <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{character.description}</p>

              {/* Top personality traits - only show top 3 */}
              {character.personality && (
                <div className="flex flex-wrap gap-1 mb-2">
                  {Object.entries(character.personality)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 3)
                    .map(([trait, value]) => (
                      <span
                        key={trait}
                        className={`text-xs px-1.5 py-0.5 rounded-sm ${
                          value >= 8 ? 'bg-primary/20 text-primary font-medium' : 'bg-secondary/30'
                        }`}
                        title={`${trait}: ${value}/10`}
                      >
                        {trait} {value >= 8 ? '★' : ''}
                      </span>
                    ))}
                </div>
              )}

              {/* Compact stats */}
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <span>Talk:</span>
                  <div className="w-10 h-1.5 bg-secondary/30 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary/60 rounded-full"
                      style={{ width: `${(character.talkativeness / 10) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <span>Think:</span>
                  <div className="w-10 h-1.5 bg-secondary/30 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary/60 rounded-full"
                      style={{ width: `${(character.thinkingSpeed / 2) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Action buttons - fixed at bottom */}
      <div className="sticky bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t p-3 flex justify-end gap-3">
        <div className="flex-1 flex items-center">
          {selectedCharacters.length > 0 ? (
            <span className="text-sm">
              <span className="font-medium">{selectedCharacters.length}</span> character{selectedCharacters.length !== 1 ? 's' : ''} selected
            </span>
          ) : (
            <span className="text-sm text-muted-foreground">Select characters to begin</span>
          )}
        </div>
        <button
          onClick={onStartChat}
          disabled={selectedCharacters.length === 0}
          className={`inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium shadow transition-colors ${
            selectedCharacters.length === 0
              ? 'bg-primary/50 text-primary-foreground/50 cursor-not-allowed'
              : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}
        >
          Start Chat
        </button>
      </div>
    </div>
  );
};

export default CharacterSelection;
